const enum MessageType {
    Text = "Text",
    Image = "Image"
}

export default MessageType;